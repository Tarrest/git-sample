public class RunTest {

    public static void main(String[] args) {
        Point p = new Point(-2.3, 4, 8.5, 0.7);
        double length1 = p.distance();
        System.out.println(length1);

    }
}
